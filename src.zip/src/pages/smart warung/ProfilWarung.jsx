import { useState } from 'react'
import { supabase } from '../../lib/supabase'
import { Link } from 'react-router-dom'

export default function ProfilWarung({ profile, onUpdate }) {
  const [editing, setEditing] = useState(false)
  const [form, setForm] = useState({
    nama_warung: profile.nama_warung,
    deskripsi: profile.deskripsi || '',
    jam_buka: profile.jam_buka || '',
    jam_tutup: profile.jam_tutup || '',
    jenis_makanan: profile.jenis_makanan || '',
  })
  const [loading, setLoading] = useState(false)

  async function handleSave() {
    setLoading(true)
    await supabase.from('warung_profiles')
      .update(form).eq('id', profile.id)
    setLoading(false)
    setEditing(false)
    onUpdate()
  }

  const inputClass = "w-full px-3 py-2.5 rounded-xl border border-[#e8e4db] bg-[#faf9f7] text-sm focus:outline-none focus:ring-2 focus:ring-[#F4A261]/30 focus:border-[#F4A261]"

  const verifiedProgress = Math.min((profile.total_donasi / 20) * 100, 100)

  return (
    <div className="space-y-4">

      {/* Lumbung Verified Progress */}
      <div className={`rounded-2xl p-4 border ${
        profile.is_verified
          ? 'bg-[#f0faf4] border-[#b7e4cc]'
          : 'bg-white border-[#e8e4db]'
      }`}>
        <div className="flex items-center gap-3 mb-3">
          <span className="text-2xl">{profile.is_verified ? '✅' : '🏅'}</span>
          <div className="flex-1">
            <p className="text-sm font-semibold text-[#1a3a2a]">
              {profile.is_verified ? 'Lumbung Verified!' : 'Menuju Lumbung Verified'}
            </p>
            <p className="text-xs text-[#9a9a8a]">
              {profile.is_verified
                ? 'Warungmu dipercaya komunitas LUMBUNG'
                : `Donasi ${Math.max(0, 20 - profile.total_donasi)}x lagi untuk verified`}
            </p>
          </div>
          <span className="text-sm font-bold text-[#2D6A4F]">
            {profile.total_donasi}/20
          </span>
        </div>
        <div className="bg-[#f0ece4] rounded-full h-2 overflow-hidden">
          <div
            className="h-2 bg-gradient-to-r from-[#F4A261] to-[#2D6A4F] rounded-full transition-all"
            style={{ width: `${verifiedProgress}%` }}
          />
        </div>
      </div>

      {/* Statistik */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Total Donasi', value: profile.total_donasi, icon: '📤', color: 'text-[#F4A261]' },
          { label: 'Rating', value: profile.rating_avg?.toFixed(1) || '0.0', icon: '⭐', color: 'text-yellow-500' },
          { label: 'Status', value: profile.is_verified ? 'Verified' : 'Reguler', icon: '🏅', color: 'text-[#2D6A4F]' },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-2xl border border-[#e8e4db] p-3 text-center">
            <div className="text-xl mb-1">{s.icon}</div>
            <div className={`text-sm font-bold ${s.color}`}>{s.value}</div>
            <div className="text-xs text-[#9a9a8a] mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Edit / Detail Profil */}
      <div className="bg-white rounded-2xl border border-[#e8e4db] p-4">
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm font-semibold text-[#1a3a2a]">Detail Profil</p>
          <button
            onClick={() => setEditing(!editing)}
            className="text-xs text-[#F4A261] font-semibold border border-[#f9d4a7] px-3 py-1 rounded-full"
          >
            {editing ? 'Batal' : '✏️ Edit'}
          </button>
        </div>

        {editing ? (
          <div className="space-y-3">
            <input value={form.nama_warung}
              onChange={e => setForm(f => ({...f, nama_warung: e.target.value}))}
              placeholder="Nama warung" className={inputClass} />
            <textarea value={form.deskripsi}
              onChange={e => setForm(f => ({...f, deskripsi: e.target.value}))}
              placeholder="Deskripsi warung" rows={2}
              className={inputClass + ' resize-none'} />
            <input value={form.jenis_makanan}
              onChange={e => setForm(f => ({...f, jenis_makanan: e.target.value}))}
              placeholder="Jenis makanan" className={inputClass} />
            <div className="grid grid-cols-2 gap-2">
              <input type="time" value={form.jam_buka}
                onChange={e => setForm(f => ({...f, jam_buka: e.target.value}))}
                className={inputClass} />
              <input type="time" value={form.jam_tutup}
                onChange={e => setForm(f => ({...f, jam_tutup: e.target.value}))}
                className={inputClass} />
            </div>
            <button onClick={handleSave} disabled={loading}
              className="w-full py-3 rounded-2xl bg-[#F4A261] text-white text-sm font-semibold disabled:opacity-50">
              {loading ? 'Menyimpan...' : '💾 Simpan Perubahan'}
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {[
              { label: 'Nama Warung', value: profile.nama_warung },
              { label: 'Jenis Makanan', value: profile.jenis_makanan },
              { label: 'Jam Operasional', value: `${profile.jam_buka} - ${profile.jam_tutup}` },
              { label: 'Deskripsi', value: profile.deskripsi || '-' },
            ].map(item => (
              <div key={item.label} className="flex justify-between text-xs py-2 border-b border-[#f0ece4] last:border-0">
                <span className="text-[#9a9a8a]">{item.label}</span>
                <span className="text-[#1a3a2a] font-medium text-right max-w-[60%]">{item.value}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3">
        <Link to="/donasi/buat"
          className="bg-[#fef3e7] border border-[#f9d4a7] rounded-2xl p-4 text-center hover:shadow-md transition-all">
          <div className="text-2xl mb-1">📤</div>
          <p className="text-xs font-semibold text-[#d4720a]">Posting Donasi</p>
        </Link>
        <Link to="/donasi/jadwal"
          className="bg-[#f0faf4] border border-[#b7e4cc] rounded-2xl p-4 text-center hover:shadow-md transition-all">
          <div className="text-2xl mb-1">⏰</div>
          <p className="text-xs font-semibold text-[#2D6A4F]">Jadwal Donasi</p>
        </Link>
      </div>
    </div>
  )
}