import { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'

export default function CSRDashboard({ userId }) {
  const [data, setData] = useState(null)
  const [trenBulanan, setTrenBulanan] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { fetchData() }, [])

  async function fetchData() {
    const { data: donasi } = await supabase
      .from('donasi').select('*').eq('donor_id', userId)

    const total = donasi?.length || 0
    const diambil = donasi?.filter(d => d.status === 'diambil').length || 0
    const totalPorsi = donasi?.reduce((sum, d) => sum + (d.jumlah_porsi || 0), 0) || 0
    const foodWaste = Math.round(totalPorsi * 0.3)
    const co2 = Math.round(foodWaste * 2.5)

    // Tren 6 bulan terakhir
    const bulanIni = new Date()
    const tren = []
    for (let i = 5; i >= 0; i--) {
      const d = new Date(bulanIni.getFullYear(), bulanIni.getMonth() - i, 1)
      const bulanLabel = d.toLocaleDateString('id-ID', { month: 'short' })
      const donasiMonth = donasi?.filter(don => {
        const dt = new Date(don.created_at)
        return dt.getMonth() === d.getMonth() && dt.getFullYear() === d.getFullYear()
      }) || []
      tren.push({
        bulan: bulanLabel,
        jumlah: donasiMonth.length,
        porsi: donasiMonth.reduce((s, d) => s + (d.jumlah_porsi || 0), 0)
      })
    }

    setData({ total, diambil, totalPorsi, foodWaste, co2 })
    setTrenBulanan(tren)
    setLoading(false)
  }

  if (loading) return (
    <div className="text-center py-10">
      <div className="text-3xl animate-bounce mb-2">📊</div>
      <p className="text-xs text-[#9a9a8a]">Memuat data CSR...</p>
    </div>
  )

  const maxPorsi = Math.max(...trenBulanan.map(t => t.porsi), 1)

  return (
    <div className="space-y-4">

      {/* Info Banner */}
      <div className="bg-[#f0faf4] rounded-2xl p-4 border border-[#b7e4cc]">
        <p className="text-xs font-semibold text-[#2D6A4F] mb-1">📊 Dashboard CSR</p>
        <p className="text-xs text-[#5a7a6a] leading-relaxed">
          Laporan dampak sosial dan lingkungan dari program donasi warungmu. Data ini bisa dipakai untuk laporan sustainability bisnis.
        </p>
      </div>

      {/* Impact Cards */}
      <div className="grid grid-cols-2 gap-3">
        {[
          { icon: '👨‍👩‍👧', label: 'Keluarga Terbantu', value: data.diambil, unit: 'keluarga', color: 'text-[#2D6A4F]', bg: 'bg-[#f0faf4]' },
          { icon: '🍱', label: 'Porsi Tersalurkan', value: data.totalPorsi, unit: 'porsi', color: 'text-[#F4A261]', bg: 'bg-[#fef3e7]' },
          { icon: '♻️', label: 'Food Waste Diselamatkan', value: `${data.foodWaste} kg`, unit: 'estimasi', color: 'text-green-600', bg: 'bg-green-50' },
          { icon: '🌍', label: 'CO₂ Dihemat', value: `${data.co2} kg`, unit: 'estimasi', color: 'text-blue-500', bg: 'bg-blue-50' },
        ].map(s => (
          <div key={s.label} className={`${s.bg} rounded-2xl p-4 border border-[#e8e4db]`}>
            <div className="text-2xl mb-2">{s.icon}</div>
            <div className={`text-xl font-bold ${s.color}`}>{s.value}</div>
            <div className="text-xs text-[#9a9a8a] mt-0.5">{s.unit}</div>
            <div className="text-xs font-medium text-[#4a4a3a] mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Tren Bulanan */}
      <div className="bg-white rounded-2xl border border-[#e8e4db] p-4">
        <p className="text-sm font-semibold text-[#1a3a2a] mb-4">📈 Tren Donasi 6 Bulan</p>
        <div className="flex items-end gap-2 h-24">
          {trenBulanan.map((t, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <div className="text-xs font-bold text-[#F4A261]">
                {t.porsi > 0 ? t.porsi : ''}
              </div>
              <div
                className="w-full rounded-t-lg bg-[#F4A261] transition-all"
                style={{ height: `${Math.max((t.porsi / maxPorsi) * 64, t.porsi > 0 ? 4 : 0)}px` }}
              />
              <div className="text-[10px] text-[#9a9a8a]">{t.bulan}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Sertifikat CSR */}
      <div className="bg-gradient-to-r from-[#F4A261] to-[#e8924f] rounded-2xl p-4 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs opacity-80 mb-1">Laporan Dampak Sosial</p>
            <p className="text-sm font-bold">Download Sertifikat CSR</p>
            <p className="text-xs opacity-75 mt-1">
              {data.diambil} keluarga · {data.totalPorsi} porsi · {data.foodWaste}kg food waste diselamatkan
            </p>
          </div>
          <button
            onClick={() => alert('Fitur download PDF akan segera tersedia!')}
            className="bg-white text-[#d4720a] text-xs font-bold px-3 py-2 rounded-xl flex-shrink-0 ml-3"
          >
            📄 Download
          </button>
        </div>
      </div>

      {/* Roadmap */}
      <div className="bg-white rounded-2xl border border-[#e8e4db] p-4">
        <p className="text-xs font-semibold text-[#4a4a3a] mb-3">🔗 Integrasi Mendatang (Roadmap)</p>
        {[
          { icon: '🟢', label: 'GoFood Integration', desc: 'Tarik data stok otomatis dari GoFood' },
          { icon: '🟠', label: 'ShopeeFood Integration', desc: 'Deteksi menu hampir expired otomatis' },
          { icon: '🔵', label: 'Laporan ESG PDF', desc: 'Export laporan sustainability lengkap' },
        ].map(r => (
          <div key={r.label} className="flex items-start gap-3 py-2 border-b border-[#f0ece4] last:border-0">
            <span className="text-sm mt-0.5">{r.icon}</span>
            <div>
              <p className="text-xs font-medium text-[#1a3a2a]">{r.label}</p>
              <p className="text-xs text-[#9a9a8a]">{r.desc}</p>
            </div>
            <span className="ml-auto text-xs text-[#9a9a8a] bg-[#f5f3ee] px-2 py-0.5 rounded-full flex-shrink-0">
              Soon
            </span>
          </div>
        ))}
      </div>

    </div>
  )
}